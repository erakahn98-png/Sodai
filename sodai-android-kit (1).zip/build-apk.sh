#!/usr/bin/env bash
set -e
npx @bubblewrap/cli init --manifest="https://ais-dev-ycx3t2hd352gisdledyn73-719448470316.asia-east1.run.app/manifest.webmanifest"
npx @bubblewrap/cli build
echo "Done! Install app-release-signed.apk on your Android device."