SODAI Online Android App Packaging Kit
======================================
Live Online Web App URL: https://ais-dev-ycx3t2hd352gisdledyn73-719448470316.asia-east1.run.app
Web Manifest URL: https://ais-dev-ycx3t2hd352gisdledyn73-719448470316.asia-east1.run.app/manifest.webmanifest
Google Sitemap URL: https://ais-dev-ycx3t2hd352gisdledyn73-719448470316.asia-east1.run.app/sitemap.xml
Mode: Online-Only (Live server data & real-time updates)
Android Permissions: android.permission.INTERNET, android.permission.ACCESS_NETWORK_STATE

Included AndroidManifest.xml (android/app/src/main/AndroidManifest.xml)
----------------------------------------------------------------------
Pre-configured with <uses-permission android:name="android.permission.INTERNET" />
and <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />.

Option 1: Instant Android Online App Install (Recommended)
----------------------------------------------------------
1. Open https://ais-dev-ycx3t2hd352gisdledyn73-719448470316.asia-east1.run.app in Google Chrome on Android.
2. Tap "অ্যাপ ইনস্টল" / "Install App" or Chrome Menu -> "Install App".
3. Chrome creates a signed WebAPK that opens SODAI online like a native app.

Option 2: Signed Online .APK via PWABuilder (Browser-Based)
-----------------------------------------------------------
1. Open https://www.pwabuilder.com and enter your public HTTPS URL (e.g. https://ais-dev-ycx3t2hd352gisdledyn73-719448470316.asia-east1.run.app).
2. Click "Package for stores" -> Android -> Download signed .apk.
3. Install the APK on your Android phone (connects live online to SODAI).

Option 3: Build Standalone Signed Android APK (.apk / .aab) Locally
-------------------------------------------------------------------
1. Install Node.js 18+ & Java 17 (JDK), then run the included build-apk.sh or:
   npx @bubblewrap/cli init --manifest=https://ais-dev-ycx3t2hd352gisdledyn73-719448470316.asia-east1.run.app/manifest.webmanifest
2. Build the signed APK:
   npx @bubblewrap/cli build
3. Install app-release-signed.apk on any Android phone.

Option 4: Capacitor Online Wrapper
----------------------------------
Use the included capacitor.config.json and android/app/src/main/AndroidManifest.xml
with `npx cap add android && npx cap open android`.